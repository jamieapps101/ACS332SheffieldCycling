var searchData=
[
  ['_5fsetup',['_setup',['../classrepast_1_1relogo_1_1_observer.html#aa84ed23a631c997aaf5942eb22becfa5',1,'repast::relogo::Observer']]]
];
